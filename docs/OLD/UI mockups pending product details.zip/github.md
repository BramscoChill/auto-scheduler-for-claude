repo: BramscoChill/auto-scheduler-for-claude
branch: main

## Last sync
date: 2026-08-11T06:25:00Z

### Updated in this project
- Added wireframes for an expanded popup that keeps the usage display and adds the task queue.
- Task statuses, thresholds and log record follow the real registry and state-file model.

## Screen map
| Project screen | Repo files |
| --- | --- |
| Task Queue Wireframes.dc.html — 1a/1b/1c expanded popup | auto_scheduler_for_claude/popup/popup.html, popup.css, tasks.py, docs/task-queue.md |
| Task Queue Wireframes.dc.html — 1d add task | auto_scheduler_for_claude/tasks.py, docs/task-queue.md |
| Task Queue Wireframes.dc.html — 1e task detail | docs/task-queue.md |
